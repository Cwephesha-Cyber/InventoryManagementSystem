# Design and testing notes

## 1. System overview
The program manages a small store's inventory. Each item has an ID, name,
quantity and price. An array named `inventory` stores up to 100 `Item`
structures. `itemCount` records how many array positions are currently in use.

## 2. Main algorithm
1. Create an empty array of 100 items and set itemCount to zero.
2. Display the menu.
3. Read and validate the user's menu choice.
4. Use a selection statement (`switch`) to call the selected function.
5. Repeat the menu until the user selects Exit.

## 3. Pseudocode

```text
START
    create array inventory[100]
    itemCount = 0
    REPEAT
        display menu
        read menu choice
        IF choice = 1 THEN add item
        ELSE IF choice = 2 THEN display inventory
        ELSE IF choice = 3 THEN update quantity
        ELSE IF choice = 4 THEN search item
        ELSE IF choice = 5 THEN calculate total value
        ELSE IF choice = 6 THEN display exit message
        ELSE display invalid choice message
    UNTIL choice = 6
END
```

## 4. Add-item pseudocode

```text
IF itemCount = 100 THEN
    display inventory full message
    stop this operation
END IF
read item ID
IF ID is not positive OR ID already exists THEN
    display error message
    stop this operation
END IF
read non-empty item name
read quantity until quantity is zero or greater
read price until price is zero or greater
store values in inventory[itemCount]
itemCount = itemCount + 1
display success message
```

## 5. Inventory value algorithm

```text
total = 0
FOR each item from index 0 to itemCount - 1
    total = total + (item quantity * item price)
END FOR
display total
```

## 6. Flowchart (text form)

```text
             +-------+
             | START |
             +---+---+
                 |
       +---------v----------+
       | Initialise array   |
       | and itemCount = 0  |
       +---------+----------+
                 |
          +------v------+
          | Display menu|
          +------+------+
                 |
          +------v------+
          | Read choice |
          +------+------+
                 |
          +------v----------------+
          | Is choice 1, 2, 3, 4, 5|
          | or 6?                  |
          +--+------------------+-+
             |                  |
       1 to 5|                  |6
             v                  v
    +--------+--------+     +----+----+
    | Run selected    |     |  EXIT   |
    | operation       |     +---------+
    +--------+--------+
             |
             +----------> back to Display menu
```

## 7. Functions and C++ concepts used
- `struct Item`: groups the four required item fields.
- `Item inventory[MAX_ITEMS]`: array of structures.
- `if`, `else`, and `switch`: selection/decision statements.
- `for`, `while`, and `do-while`: repetition and input validation.
- Functions: separate adding, displaying, updating, searching and calculation.
- `const`: protects values such as the maximum array size and read-only arrays.
- `string`: stores item names, including names containing spaces.

## 8. Test plan
Run each test and record the actual result and whether it passed on your computer.

| Test | Action / input | Expected result |
|---|---|---|
| 1 | Start program | Menu is displayed |
| 2 | Add ID 101, Exercise Book, quantity 20, price 12.50 | Item added successfully |
| 3 | Add another item with ID 101 | Duplicate ID is rejected |
| 4 | Add an item with negative ID | Item is rejected |
| 5 | Enter a negative quantity | Program asks again; negative quantity is not stored |
| 6 | Enter a negative price | Program asks again; negative price is not stored |
| 7 | Display inventory | All stored items and their values are displayed |
| 8 | Update ID 101 to quantity 25 | Quantity changes to 25 |
| 9 | Search for ID 101 | Matching item is displayed |
| 10 | Search for an ID that does not exist | Not-found message is displayed |
| 11 | Search by part of an item name | Matching name(s) are displayed, ignoring letter case |
| 12 | Calculate value for sample data in README | Total is 1,300.00 before any quantity updates |
| 13 | Enter 9 at the main menu | Invalid menu choice message is displayed |
| 14 | Try adding more than 100 different items | Full-inventory message is displayed |
| 15 | Select 6 | Exit message is displayed and program ends |

## 9. Limitations and possible improvements
- Inventory data is not saved after the program closes because the required
  project specifies an array and does not require file or database storage.
- The array has a fixed capacity of 100 items.
- A future version could save and load records from a file, support deleting
  items, sort inventory, and use a database for larger stores.

## 10. Evidence to collect for the report
Take your own screenshots in Code::Blocks showing:
1. The source code open in the IDE.
2. A successful build/run.
3. Adding an item.
4. Displaying all items.
5. Updating an item's quantity.
6. Searching for an item (include one unsuccessful search).
7. The total inventory value.
8. An invalid menu choice or duplicate ID being rejected.

Write your evaluation from the tests you actually perform. Do not claim a test
passed until you have run it and observed the result.
