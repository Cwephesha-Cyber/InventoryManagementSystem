#include <iostream>
#include <iomanip>
#include <string>
#include <limits>
#include <algorithm>
#include <cctype>

using namespace std;

const int MAX_ITEMS = 100;


struct Item {
    int itemID;
    string itemName;
    int quantity;
    double price;
};


int readInteger(const string& prompt) {
    int value;
    while (true) {
        cout << prompt;
        if (cin >> value) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
        cout << "Invalid input. Please enter a whole number.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}


double readNonNegativeNumber(const string& prompt) {
    double value;
    while (true) {
        cout << prompt;
        if (cin >> value && value >= 0) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
        cout << "Invalid input. Please enter a number that is zero or greater.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}


string readNonEmptyText(const string& prompt) {
    string value;
    while (true) {
        cout << prompt;
        getline(cin, value);
        if (value.find_first_not_of(" \t") != string::npos) {
            return value;
        }
        cout << "This field cannot be empty. Please try again.\n";
    }
}


string toLowerCase(string text) {
    transform(text.begin(), text.end(), text.begin(),
              [](unsigned char character) { return static_cast<char>(tolower(character)); });
    return text;
}


int findItemByID(const Item inventory[], int itemCount, int searchID) {
    for (int i = 0; i < itemCount; i++) {
        if (inventory[i].itemID == searchID) {
            return i;
        }
    }
    return -1;
}

void displayHeading() {
    cout << "\n" << left
         << setw(10) << "Item ID"
         << setw(28) << "Item Name"
         << setw(12) << "Quantity"
         << setw(14) << "Price"
         << setw(16) << "Item Value" << '\n';
    cout << string(80, '-') << '\n';
}

void displayOneItem(const Item& item) {
    cout << left << setw(10) << item.itemID
         << setw(28) << item.itemName.substr(0, 26)
         << setw(12) << item.quantity
         << setw(2) << " " << right << fixed << setprecision(2) << setw(10) << item.price
         << setw(16) << item.quantity * item.price << left << '\n';
}


void addItem(Item inventory[], int& itemCount) {
    if (itemCount >= MAX_ITEMS) {
        cout << "The inventory is full. No more items can be added.\n";
        return;
    }

    cout << "\n--- Add New Item ---\n";
    int newID = readInteger("Enter item ID (positive whole number): ");
    if (newID <= 0) {
        cout << "Item ID must be greater than zero. Item was not added.\n";
        return;
    }
    if (findItemByID(inventory, itemCount, newID) != -1) {
        cout << "That item ID already exists. Duplicate IDs are not allowed.\n";
        return;
    }

    string newName = readNonEmptyText("Enter item name: ");
    int newQuantity;
    do {
        newQuantity = readInteger("Enter quantity (zero or greater): ");
        if (newQuantity < 0) {
            cout << "Quantity cannot be negative. Please try again.\n";
        }
    } while (newQuantity < 0);

    double newPrice = readNonNegativeNumber("Enter price (zero or greater): ");

    inventory[itemCount].itemID = newID;
    inventory[itemCount].itemName = newName;
    inventory[itemCount].quantity = newQuantity;
    inventory[itemCount].price = newPrice;
    itemCount++;

    cout << "Item added successfully.\n";
}


void displayInventory(const Item inventory[], int itemCount) {
    cout << "\n--- Current Inventory ---\n";
    if (itemCount == 0) {
        cout << "The inventory is empty.\n";
        return;
    }

    displayHeading();
    for (int i = 0; i < itemCount; i++) {
        displayOneItem(inventory[i]);
    }
    cout << string(80, '-') << '\n';
    cout << "Number of different items: " << itemCount << '\n';
}


void updateQuantity(Item inventory[], int itemCount) {
    cout << "\n--- Update Item Quantity ---\n";
    if (itemCount == 0) {
        cout << "The inventory is empty. Add an item first.\n";
        return;
    }

    int searchID = readInteger("Enter the ID of the item to update: ");
    int position = findItemByID(inventory, itemCount, searchID);
    if (position == -1) {
        cout << "No item was found with ID " << searchID << ".\n";
        return;
    }

    cout << "Item: " << inventory[position].itemName << '\n';
    cout << "Current quantity: " << inventory[position].quantity << '\n';
    int newQuantity;
    do {
        newQuantity = readInteger("Enter the new quantity (zero or greater): ");
        if (newQuantity < 0) {
            cout << "Quantity cannot be negative. Please try again.\n";
        }
    } while (newQuantity < 0);

    inventory[position].quantity = newQuantity;
    cout << "Quantity updated successfully.\n";
}


void searchItem(const Item inventory[], int itemCount) {
    cout << "\n--- Search Item ---\n";
    if (itemCount == 0) {
        cout << "The inventory is empty.\n";
        return;
    }

    cout << "1. Search by item ID\n";
    cout << "2. Search by item name\n";
    int choice;
    do {
        choice = readInteger("Choose a search method: ");
        if (choice != 1 && choice != 2) {
            cout << "Please choose 1 or 2.\n";
        }
    } while (choice != 1 && choice != 2);

    if (choice == 1) {
        int searchID = readInteger("Enter item ID: ");
        int position = findItemByID(inventory, itemCount, searchID);
        if (position == -1) {
            cout << "No item was found with ID " << searchID << ".\n";
        } else {
            displayHeading();
            displayOneItem(inventory[position]);
        }
    } else {
        string searchName = toLowerCase(readNonEmptyText("Enter item name or part of the name: "));
        bool found = false;
        for (int i = 0; i < itemCount; i++) {
            if (toLowerCase(inventory[i].itemName).find(searchName) != string::npos) {
                if (!found) {
                    displayHeading();
                }
                displayOneItem(inventory[i]);
                found = true;
            }
        }
        if (!found) {
            cout << "No item matching that name was found.\n";
        }
    }
}


void calculateInventoryValue(const Item inventory[], int itemCount) {
    double totalValue = 0.0;
    for (int i = 0; i < itemCount; i++) {
        totalValue += inventory[i].quantity * inventory[i].price;
    }
    cout << "\n--- Total Inventory Value ---\n";
    cout << fixed << setprecision(2);
    cout << "Total value: " << totalValue << '\n';
}

void displayMenu() {
    cout << "\n====================================================================================\n";
    cout << "                          BLACK BHUNU INVENTORY MANAGEMENT SYSTEM      \n";
    cout << "=======================================================================================\n";
    cout << "1. Add a new item\n";
    cout << "2. Display all items\n";
    cout << "3. Update item quantity\n";
    cout << "4. Search for an item\n";
    cout << "5. Calculate total inventory value\n";
    cout << "6. Exit\n";
    cout << "======================================================================================\n";
}

int main() {
    Item inventory[MAX_ITEMS];
    int itemCount = 0;
    int choice;

    cout << "Welcome to Black Bhunu Systems!\n";

    do {
        displayMenu();
        choice = readInteger("Enter your choice (1-6): ");

        switch (choice) {
            case 1:
                addItem(inventory, itemCount);
                break;
            case 2:
                displayInventory(inventory, itemCount);
                break;
            case 3:
                updateQuantity(inventory, itemCount);
                break;
            case 4:
                searchItem(inventory, itemCount);
                break;
            case 5:
                calculateInventoryValue(inventory, itemCount);
                break;
            case 6:
                cout << "Thank you for using the our Systems. Goodbye!\n";
                break;
            default:
                cout << "Invalid menu choice. Please select a number from 1 to 6.\n";
        }
    } while (choice != 6);

    return 0;
}
